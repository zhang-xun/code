#include "dialog.h"
#include "ui_dialog.h"
#include <QDebug>
#include <QMessageBox>
#include <stdlib.h>
#include <QDateTime>
#include<stdio.h>
#include<iostream>
#include<string>
#include<fstream>
#include"ImgSet.h"
//#include"ImgSet.cpp"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


Dialog::Dialog(QWidget *parent) :
QDialog(parent),
ui(new Ui::Dialog)
{
    ui->setupUi(this);
    strDir = "/home/savePic";
    char strTemp[128];
    cam = NULL;
    timer = new QTimer(this);
    imag = new QImage();         // ��ʼ��

    //��ʼ����ʱ�򽫹رպͲɼ�����ʧ��
    ui->pushButton_3->setEnabled(false);
    ui->takingPictures->setEnabled(false);

    sprintf(strTemp, "mkdir %s -p", strDir);
    system(strTemp);//û��Ŀ¼�򴴽�Ŀ¼
    /*�źźͲ�*/
    connect(timer, SIGNAL(timeout()), this, SLOT(readFarme()));  // ʱ
}

Dialog::~Dialog()
{
    delete ui;
}


Mat Dialog::f_picinit(Mat rgb, Mat mask)
{
    //ofstream fid("C:\\Users\\lenovo\\Desktop\\mask.txt");
    int	row_mask = mask.rows;
    int col_mask = mask.cols;
    int row_pic = rgb.rows;
    int col_pic = rgb.cols;
    //Mat mask1(mask.rows,mask.cols,CV_32FC1,Scalar::all(0));
    //mask1.data=mask2.data;
    if (row_mask != row_pic || col_mask != col_pic)
    {
        cout << "mask size do not match!";
        Mat M(3, 3, CV_32FC1, Scalar::all(0));
        return M;
    }
    Mat imageBlue, imageGreen, imageRed;
    Mat mergeImage;
    //����һ��Mat�������������ֺ������  
    QVector<Mat> Qchannels;
	std::vector<Mat> channels = Qchannels.toStdVector();
    //�ж��ļ������Ƿ���ȷ  
    assert(rgb.data != NULL);

    //ͨ���Ĳ��  
    cv::split(rgb, channels);

    uchar* c0 = (channels.at(0).data);
    uchar* maskmat = (mask.data);
    //��maskmat���д�����ʹ��ֵΪ0��1
    for (int i = 0; i < mask.rows*mask.cols; i++)
    {
        //cout<<(int)maskmat[i]<<" ";
        if (((int)maskmat[i]) != 0)
            maskmat[i] = (int)1;
        // cout<<(int)maskmat[i]<<endl;
    }
    mask.data = maskmat;
    /*for(int i=0;i<mask.rows;i++)
    {	for(int j=0;j<mask.cols;j++)
    {
    fid<<(int)maskmat[i*mask.step+j]<<" ";

    }
    fid<<endl;
    }*/
    for (int i = 0; i < (channels.at(0).rows)*(channels.at(0).cols); i++)
    {

        c0[i] = (int)c0[i] * (int)maskmat[i];
    }
    channels.at(0).data = c0;

    uchar* c1 = (channels.at(1).data);
    for (int i = 0; i < (channels.at(0).rows)*(channels.at(0).cols); i++)
    {
        c1[i] = (int)c1[i] * (int)maskmat[i];
    }
    channels.at(1).data = c1;

    uchar* c2 = (channels.at(2).data);
    for (int i = 0; i < (channels.at(0).rows)*(channels.at(0).cols); i++)
    {
        c2[i] = (int)c2[i] * (int)maskmat[i];
    }
    channels.at(2).data = c2;
    /* for(int i=0;i<mask.rows*mask.cols;i++)
      {
      cout<<(int)channels.at(2).data[i]<<" ";

      cout<<(int)maskmat[i]<<endl;
      }*/
    //channels.at(0)=channels.at(0).mul(mask);
    //channels.at(1)=channels.at(1).mul(mask);
    //channels.at(2)=channels.at(2).mul(mask);
    //�Բ�ֵ�ͨ�����ݺϲ�  
    merge(channels, mergeImage);
    //imwrite( "C:\\Users\\lenovo\\Desktop\\�½��ļ��� (3)\\cmaskorg.jpg", mergeImage);  
    //imshow("mergeImage",mergeImage); 
    //cvWaitKey();
    /*cvNamedWindow("mergeImage",CV_WINDOW_AUTOSIZE);
    cvShowImage("mergeImage",mergeImage.);
    cvWaitKey(0);
    cvDestroyWindow("mergeImage"); */

    //fid.close();
    return mergeImage;
}
Mat Dialog::f_getBinaryFeature2D(Mat hsv, int interval1[], int len_intval1, int interval2[], int len_intval2, float interval_s[], int len_int_s)
{
    //ofstream fid("C:\\Users\\lenovo\\Desktop\\v.txt");
    //ifstream finh("C:\\Users\\lenovo\\Desktop\\h.txt");
    //ifstream fins("C:\\Users\\lenovo\\Desktop\\s.txt");
    //ifstream finv("C:\\Users\\lenovo\\Desktop\\v.txt");

    //����һ��Mat�������������ֺ������  
    QVector<Mat> Qchannels;
	std::vector<Mat> channels = Qchannels.toStdVector();

    //�ж��ļ������Ƿ���ȷ  
    assert(hsv.data != NULL);
    //namedWindow("image",CV_WINDOW_AUTOSIZE);  
    //namedWindow("mergeImage",CV_WINDOW_AUTOSIZE);  

    //ͨ���Ĳ��  
    cv::split(hsv, channels);
    Mat h = channels.at(0);
    Mat s = channels.at(1);
    Mat v = channels.at(2);



    int len_int = len_intval1 + len_intval2;
    int **HS = new int*[len_int];
    int totalpixel = 0;
    for (int i = 0; i < len_int; i++)
    {
        HS[i] = new int[len_int_s];
    }
    for (int i = 0; i < len_int; i++)
    for (int j = 0; j < len_int_s; j++)
    {
        HS[i][j] = 0;
    }
    Mat feature(len_int, len_int_s, CV_32FC1, Scalar::all(0));
    for (int k = 0; k < h.rows; k++)
    for (int l = 0; l < h.cols; l++)
    {
        float hv1 = h.at<float>(k, l);
        float sv1 = s.at<float>(k, l);
        float vv1 = v.at<float>(k, l);
        double hv = (double)hv1;
        double sv = (double)sv1;
        double vv = (double)vv1;

        /*float hv=0;
        float sv=0;
        float vv=0;
        string temp="";
        finh>>temp;
        hv=atof(temp.c_str());

        fins>>temp;
        sv=atof(temp.c_str());

        finv>>temp;
        vv=atof(temp.c_str());*/

        for (int i = 0; i < len_intval2; i++)
        {
            // ����350��360
            for (int j = 0; j < len_int_s; j++)
            {
                if (hv >= interval2[i] && hv < interval2[i + 1] && sv >= interval_s[j] && sv<interval_s[j + 1] && vv>0.15)
                {
                    HS[i][j]++;
                    totalpixel += 1;
                }
            }
            if (hv >= interval2[i] && hv<interval2[i + 1] && sv == interval_s[len_int_s] && vv>0.15)
            {
                HS[i][len_int_s - 1] = HS[i][len_int_s - 1] + 1;
                totalpixel += 1;
            }
        }
        // ����0 ��40
        for (int i = len_intval2; i < len_int; i++)
        {
            for (int j = 0; j < len_int_s; j++)
            {
                if (hv >= interval1[i - 1] && hv < interval1[i] && sv >= interval_s[j] && sv<interval_s[j + 1] && vv>0.15)
                {
                    HS[i][j]++;
                    totalpixel += 1;
                }
            }
            if (hv >= interval1[i - 1] && hv<interval1[i] && sv == interval_s[len_int_s] && vv>0.15)
            {
                HS[i][len_int_s - 1] += 1;
                totalpixel += 1;
            }
        }
        //�������40 ��
        for (int j = 0; j < len_int_s; j++)
        {
            if (hv == interval1[len_intval1 - 1] && sv >= interval_s[j] && sv<interval_s[j + 1] && vv>0.15)
            {
                HS[len_int - 1][j] += 1;
                totalpixel += 1;
            }
            if (hv == interval2[len_intval2] && sv >= interval_s[j] && sv<interval_s[j + 1] && vv>0.15)
            {
                HS[len_intval2][j] += 1;
                totalpixel += 1;
            }
        }

        if (hv == interval1[len_intval1 - 1] && sv == interval_s[len_int_s] && vv > 0.15)
        {
            HS[len_int - 1][len_int_s - 1] += 1;
            totalpixel += 1;
        }
        if (hv == interval2[len_intval2] && sv == interval_s[len_int_s] && vv > 0.15)
        {
            HS[len_intval2][len_int_s - 1] += 1;
            totalpixel += 1;
        }
    }

    for (int i = 0; i < len_int; i++)
    for (int j = 0; j < len_int_s; j++)
    {
        //cout<<HS[i][j]<<" "<<totalpixel<<endl;
        if ((double)((int)HS[i][j] / (double)totalpixel) < 0.004) //�趨��ֵ
        {
            feature.at<int>(i, j) = 0;

        }
        else
        {
            feature.at<int>(i, j) = 1;
        }
    }
    /*for (int i=0;i<len_int;i++)
    {
    for (int j=0;j<len_int_s;j++)
    {
    cout<<(double)((int)HS[i][j])<<" ";
    }
    cout<<endl;
    }*/
    /*for (int i=0;i<hsv.rows;i++)
    {
    for (int j=0;j<hsv.cols;j++)
    {

    fid<<v.at<float>(i,j)<<" ";
    }
    fid<<endl;
    }*/
    //fid.close();
    /*uchar* dataf=feature.data;
    for(int k=0;k<len_int*len_int_s;k++)
    {
    cout<<k<<" "<<(int)dataf[k]<<endl;
    }*/
    for (int i = 0; i < len_int; i++)
    {
        delete[]HS[i];
        //delete []feature[i];
    }
    delete[]HS;
    //delete []feature;
    //fid.close();
    return feature;
}

Mat  Dialog::rgbtohsv(Mat img)
{
    IplImage* src = &IplImage(img);
    CvSize size = cvGetSize(src);
    IplImage* floatsrc = cvCreateImage(size, IPL_DEPTH_32F, 3);
    IplImage* floathsv = cvCreateImage(size, IPL_DEPTH_32F, 3);



    //src =&IplImage(img);
    //cvShowImage( "src", src );
    //CvSize size = cvGetSize( src );

    //�Ƚ�ͼ��ת����float�͵�
    //floatsrc = cvCreateImage( size, IPL_DEPTH_32F, 3 );
    //floathsv = cvCreateImage( size, IPL_DEPTH_32F, 3 );


    //��src��8λת����32λ��float��
    cvConvertScale(src, floatsrc, (double)1.0 / 255.0, 0);//��һ��֮���ܹ���ʾ
    //Mat floatrgb=Mat(floathsv, true);
    //imwrite( "C:\\Users\\lenovo\\Desktop\\nor.jpg",floatrgb);  
    //cvConvertScale( src, floatsrc, 1, 0 );
    //cvShowImage("floatsrc",floatsrc);
    //cvWaitKey(-1);

    //��float��ͼ�� ��BGRת����HSV  �����Ҫת������������ɫ�ռ� ��ô�ı�CV_BGR2HSV����
    //cvCvtColorҪ���������������ͱ�����ȫ��ͬ������ҪתΪfloat��
    cvCvtColor(floatsrc, floathsv, CV_BGR2HSV);

    //����ͨ��ͼ�� �ֽ��3����ͨ��ͼ��H��Ӧ��ͨ��ʱ0��S��V��Ӧ��ͨ��ʱ1��2
    //cvCvtPixToPlane(picHSV, h_plane, s_plane, v_plane, 0);

    Mat hsv = Mat(floathsv, true);
    cvReleaseImage(&floathsv);
    cvReleaseImage(&floatsrc);

    return hsv;
}

void Dialog::split2(QString s, QVector<QString > *ret, QString separator)
{
    int last = 0;
    int index = s.indexOf(separator, last);
	printf("%d\n",11100);
    while (index != -1)
    {
		printf("%d\n",11100+index);
        ret->append(s.mid(last, index - last));
        last = index + 1;
        index = s.indexOf(separator, last);
    }
	printf("%d\n",111100);
    if (index - last > 0)
    {
        ret->append(s.mid(last, index - last));
    }
}

void Dialog::f_savefeature2D(QString mydir, int labelnum, QString pictype)
{
printf("%d\n",101);
    Mat mask = imread(".\\mask\\mask240-240.bmp", 0);  //����·��
	
printf("%d\n",102);
    //CImgSet iImgSet(mydir);  
    //   iImgSet.LoadImgsFromDir(); //��ȡĿ¼������ͼƬ
    //vector<string> file=iImgSet.GetImgName();//���ָ���ļ����µ��������ļ��к��ļ�,����ͼƬ���ƴ����files��
    QVector<QString> files;
    QVector<QString> file;//���ָ���ļ����µ��������ļ��к��ļ�,����ͼƬ���ƴ����files��
printf("%d\n",103);
    
	file.append(".\\172,img");

printf("%d\n",104);
    char  filenames[200] = { 0 };
    char dataname[200] = { 0 };
    char labelname[200] = { 0 };
    char middir[200] = "";
    char* Chmydir;
    QByteArray ba = mydir.toLatin1();
	
printf("%d\n",105);
    Chmydir = ba.data();

	printf("%d\n",106);
    strcat(middir, Chmydir);
    strcat(dataname, middir);
    strcat(dataname, "data_2dbinary.txt");
	
printf("%d\n",107);
    ofstream datafile(dataname);
printf("%d\n",108);

    strcat(labelname, middir);
    strcat(labelname, "labels_2dbinary.txt");
    ofstream labelfile(labelname);

	printf("%d\n",109);
    strcat(filenames, middir);
    strcat(filenames, "filenames_2dbinary.txt");
    ofstream fid(filenames);
printf("%d\n",110);
    for (int i = 0; i < file.size(); i++)
    {
        QVector<QString> ret;
printf("%d\n",1100+i);

        split2(file[i], &ret, "//");
        files.append(ret[ret.size() - 1]);
    }
printf("%d\n",111);
    int len = 1; //������ͼƬ����
    numofimg = len;
    Mat labels(len, 1, CV_32FC1, cv::Scalar::all(0));
    if (labelnum == 1)
    {
        labels.at<int>(0, 0) = 1;
    }
    else
    {
        labels.at<int>(0, 0) = 0;
    }
printf("%d\n",112);
    int interval1[] = { 0, 10, 18, 19, 20, 21, 22, 23, 24, 25, 26, 30, 40 };
    int interval2[] = { 350, 360 };
    float interval_s[] = { 0.2, 0.3, 0.4, 0.5, 0.6, 0.8, 1 };
    int len_feature_h = 13 - 1 + 2 - 1;
    int len_feature_s = 7 - 1;
    Mat feature_vector(len, len_feature_h*len_feature_s, CV_32FC1, Scalar::all(0));
printf("%d\n",113);
	char* Chfiles;
    for (int i = 0; i < len; i++)
    {
        char filename[200] = "";
        strcat(filename, middir);
		QByteArray ba = files.at(i).toLatin1();
		Chfiles = ba.data();
        strcat(filename,Chfiles);
        Mat im = imread(filename);
        im = f_picinit(im, mask);
        Mat hsv = rgbtohsv(im);
        Mat feature(f_getBinaryFeature2D(hsv, interval1, 12, interval2, 1, interval_s, 6));
        uchar* data = feature.data;
        fid << Chfiles << "\r\n"; //д�ļ�����filesname.txt
        // feature_vector.rowRange(i,i)=feature.reshape(0,1);
        /*for(int k=0;k<len_feature_h*len_feature_s;k++)
        {
        cout<<k<<" "<<(int )data[k]<<endl;
        }*/
        for (int col = 0; col < len_feature_h*len_feature_s; col++)
        {
            //cout<<(col)%len_feature_h<<" ";
            //cout<<(col)/len_feature_h<<" ";
            ///feature_vector.at<int>(i,col)=(int)data[(col)%len_feature_h*(len_feature_s)+(col)/len_feature_h];
            feature_vector.at<int>(i, col) = feature.at<int>((col) % len_feature_h, (col) / len_feature_h);
            //cout<<feature.at<int>((col)%len_feature_h,(col)/len_feature_h)<<endl;
        }
    }
printf("%d\n",114);
    for (int i = 0; i < feature_vector.rows; i++)
    {
        for (int j = 0; j < feature_vector.cols; j++)
        {
            datafile << feature_vector.at<int>(i, j) << " ";
        }
        datafile << endl;
    }
printf("%d\n",115);
    for (int i = 0; i < len; i++)
        labelfile << labels.at<int>(i, 0) << endl;
printf("%d\n",116);
    fid.close();
    datafile.close();
    labelfile.close();
}
void Dialog::loadfile(char * dir, Mat labels, Mat data)
{
    char  filenames[200] = "", dataname[200] = "", labelname[200] = "";
    char middir[200] = "";
    strcat(middir, dir);
    strcat(dataname, middir);
    strcat(dataname, "data_2dbinary.txt");
    strcat(labelname, middir);
    strcat(labelname, "labels_2dbinary.txt");
    strcat(filenames, middir);
    strcat(filenames, "filenames_2dbinary.txt");

    ifstream fin(dataname);
  
    char  chvalue[100];
    

    for (int row = 0; row < data.rows; row++)
    for (int i = 0; i < 78; i++)
    {
        memset(chvalue, 0, 100);
        fin >> chvalue;
        data.at<float>(row, i) = atof(chvalue);
    }
    fin.close();
    ifstream labelstream(labelname);
    
    for (int row = 0; row < labels.rows; row++)
    {
        memset(chvalue, 0, 100);
        labelstream >> chvalue;
        labels.at<float>(row, 0) = atof(chvalue);
    }
    labelstream.close();
}

//������ͷ
/****************************************
Name: on_openCamara_clicked
Description:����Ǵ�����ͷ�Ĳۺ���
Paraments: void
Return: void
other: void

Athor: majianxin
*****************************************/
void Dialog::on_openCamara_clicked()
{
    printf("%d\n",0);

    QString testdir = ".\\image";               //���Լ�����
    char testpath[100] = "";
    char* Chtestdir;
    float bestc = 3.0314;
    float bestg = 0.0625;
    printf("%d\n",1);
    f_savefeature2D(testdir, 0, "jpg");
	
printf("%d\n",2);
    Mat testlabels(numofimg, 1, CV_32FC1, Scalar::all(0));
	
printf("%d\n",3);
    Mat testinstances(numofimg, 78, CV_32FC1, Scalar::all(0));
	
printf("%d\n",4);
    QByteArray ba = testdir.toLatin1();

	printf("%d\n",5);
    Chtestdir = ba.data();
    loadfile(Chtestdir, testlabels, testinstances);
printf("%d\n",6);
    QVector<QString> testfilename;
    strcat(testpath, ".\\image");
    strcat(testpath, "filenames_2dbinary.txt");
	
printf("%d\n",7);
    ifstream ffilename(testpath);
	
printf("%d\n",8);
    char testpicname[200] = "";

    for (int i = 0; i < numofimg; i++)
    {
        ffilename >> testpicname;
        testfilename.append(testpicname);
        //ffilename>>testpicname;
    }
printf("%d\n",9);

    CvSVM SVM;
    SVM.load("newSVM.txt");

	printf("%d\n",10);
    Mat svmtestlabels(testinstances.rows, 1, CV_32FC1, Scalar::all(0));
	
printf("%d\n",11);
    SVM.predict(testinstances, svmtestlabels);
	
printf("%d\n",12);
    int truecount = 0;
    for (int i = 0; i < testinstances.rows; i++)
    {
        if (testlabels.at<float>(i, 0) == svmtestlabels.at<float>(i, 0))
        {
            truecount++;
        }
        cout << svmtestlabels.at<float>(i, 0) << endl;
    }
printf("%d\n",13);
    float accuracy = truecount / (float)testinstances.rows;
    cout << accuracy << endl;
}
//
/****************************************
Name: getTime
Description:��ȡϵͳʱ��
Paraments: void
Return: QString
other: void

Athor: majianxin
*****************************************/
QString Dialog::getTime(){

    QDateTime time = QDateTime::currentDateTime();//��ȡϵͳ���ڵ�ʱ��
    QString str = time.toString("yyyyMMddhhmmss"); //������ʾ��ʽ
    return str;
}

//����
/****************************************
Name: on_takingPictures_clicked
Description:����
Paraments: void
Return: void
other: void

Athor: majianxin
*****************************************/
void Dialog::on_takingPictures_clicked()
{
    qDebug() << "take picture";
    char strTemp[128] = { 0 };
    frame = cvQueryFrame(cam);// ������ͷ��ץȡ������ÿһ֡
    cv::Mat savePic(frame);//����ͼƬ
    QByteArray ba = getTime().toLatin1();

    sprintf(strTemp, "%s/%s.jpg", strDir, ba.data());//ƴ��ͼƬ·������

    cv::imwrite(strTemp, savePic);//����ͼƬ��ָ��λ��
    qDebug() << "save picture:" << strTemp;
}
//�ر�����ͷ
/****************************************
Name: on_pushButton_3_clicked
Description:�ر�����ͷ
Paraments: void
Return: void
other: void

Athor: majianxin
*****************************************/
void Dialog::on_pushButton_3_clicked()
{
    qDebug() << "close camara";

    timer->stop();         // ֹͣ��ȡ���ݡ�
    cvReleaseCapture(&cam);//�ͷ��ڴ�

    ui->pushButton_3->setEnabled(false);
    ui->takingPictures->setEnabled(false);
}
/****************************************
Name: readFarme
Description:��ȡ����ͷ���ݣ���ͨ��timeout��Ϣ������
Paraments: void
Return: void
other: void

Athor: majianxin
*****************************************/
void Dialog::readFarme(){
    frame = cvQueryFrame(cam);// ������ͷ��ץȡ������ÿһ֡
    // ��ץȡ����֡��ת��ΪQImage��ʽ��QImage::Format_RGB888��ͬ������ͷ�ò�ͬ�ĸ�ʽ��
    QImage image((const uchar*)frame->imageData, frame->width, frame->height, QImage::Format_RGB888);
    //��Ϊopencv�ɼ���ͼƬ�����صĸ�ʽ��BGR,��������ʾ��labelVideo�ϵ�ʱ����Ҫ����ת��:image.rgbSwapped()
    ui->labelVideo->setPixmap(QPixmap::fromImage(image.rgbSwapped()));  // ��ͼƬ��ʾ��label��
    ui->labelVideo->resize(frame->width, frame->height);//���ʴ�С
}
